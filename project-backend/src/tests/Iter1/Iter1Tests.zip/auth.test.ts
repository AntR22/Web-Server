import { channelsCreateV1 } from '../../channels';

import { channelDetailsV1, channelJoinV1 } from '../../channel';

import { authRegisterV1, authLoginV1 } from '../../auth';

import { userProfileV1 } from '../../users';

import { clearV1 } from '../../other';

beforeEach(() => {
  clearV1();
});

const ERROR = { error: expect.any(String) };

describe('test authRegisterV1 function', () => {
  // test for invalid emails
  test.each([
    { email: '' },
    { email: 'comp1531' },
    { email: 'email@unsw' },
    { email: '@example.com' },
    { email: 'paul@.com' },
    { email: 'Abc.example.com' },
    { email: 'this is"not\\ allowed@example.com' },
    { email: 'just"not"right@example.com' },
  ])("Invalid email '$email'", ({ email }) => {
    const id = authRegisterV1(email, '123456', 'Someone', 'cool');
    expect(id).toStrictEqual(ERROR);
    expect(userProfileV1(id.authUserId, id.authUserId)).toStrictEqual(ERROR);
  });

  // Test for emails already being used
  test('email used more than once', () => {
    const id = authRegisterV1('abc@email.com', '123456', 'Example', 'person');
    expect(authRegisterV1('abc@email.com', '1234567', 'Another', 'person')).toStrictEqual(ERROR);
    expect(userProfileV1(id.authUserId, id.authUserId)).toStrictEqual({
      user: {
        uId: id.authUserId,
        email: 'abc@email.com',
        nameFirst: 'Example',
        nameLast: 'person',
        handleStr: 'exampleperson',
      }
    });
  });
  test('email used more than once for multiple people registered', () => {
    const id1 = authRegisterV1('abc@email.com', '123456', 'Example', 'person');
    const id2 = authRegisterV1('123@email.com', 'abcdefg', 'Someone', 'else');

    expect(authRegisterV1('abc@email.com', '3.14159', 'Another', 'person')).toStrictEqual(ERROR);
    expect(userProfileV1(id1.authUserId, id2.authUserId)).toStrictEqual({
      user: {
        uId: id2.authUserId,
        email: '123@email.com',
        nameFirst: 'Someone',
        nameLast: 'else',
        handleStr: 'someoneelse',
      }
    });
    expect(userProfileV1(id2.authUserId, id1.authUserId)).toStrictEqual({
      user: {
        uId: id1.authUserId,
        email: 'abc@email.com',
        nameFirst: 'Example',
        nameLast: 'person',
        handleStr: 'exampleperson',
      }
    });
  });

  // Test for invalid passwords
  test.each([
    { password: '' },
    { password: 'good' },
    { password: 'p' },
    { password: '!@bad' },
  ])("Invalid password '$password'", ({ password }) => {
    const id = authRegisterV1('abc@gmail.com', password, 'test', 'person');
    expect(id).toStrictEqual(ERROR);
    expect(userProfileV1(id.authUserId, id.authUserId)).toStrictEqual(ERROR);
  });

  // Test for invalid first name of the person
  test.each([
    { Firstname: '' },
    { Firstname: 'An extremely long name that is tooooooo complicated' },
  ])("Invalid fistname '$Firstname'", ({ Firstname }) => {
    const id = authRegisterV1('abc@gmail.com', '1234567', Firstname, 'person');
    expect(id).toStrictEqual(ERROR);
    expect(userProfileV1(id.authUserId, id.authUserId)).toStrictEqual(ERROR);
  });

  // Test for invalid Last name of the person
  test.each([
    { Lastname: '' },
    { Lastname: 'An extremely long name that is tooooooo complicated' },
  ])("Invalid last name '$Lastname'", ({ Lastname }) => {
    const id = authRegisterV1('abc@gmail.com', '1234567', 'good', Lastname);
    expect(id).toStrictEqual(ERROR);
    expect(userProfileV1(id.authUserId, id.authUserId)).toStrictEqual(ERROR);
  });

  // Test for valid user details
  test('valid user tests', () => {
    const id1 = authRegisterV1('abc@email.com', '3.14159', 'Another', 'person');
    // Test for register one valid person
    expect(id1).toStrictEqual(
      {
        authUserId: expect.any(Number),
      }
    );

    expect(userProfileV1(id1.authUserId, id1.authUserId)).toStrictEqual({
      user: {
        uId: id1.authUserId,
        email: 'abc@email.com',
        nameFirst: 'Another',
        nameLast: 'person',
        handleStr: 'anotherperson'
      }
    });

    // Test for register another valid person
    const id2 = authRegisterV1('123@email.com', 'abc123', 'Someone', 'else');
    expect(id2).toStrictEqual(
      {
        authUserId: expect.any(Number),
      }
    );
    expect(userProfileV1(id1.authUserId, id2.authUserId)).toStrictEqual({
      user: {
        uId: id2.authUserId,
        email: '123@email.com',
        nameFirst: 'Someone',
        nameLast: 'else',
        handleStr: 'someoneelse',
      }
    });
  });

  test('one valid followed by an unvalid user', () => {
    // Test for register one valid person
    const id1 = authRegisterV1('lol@gmail.com', '123321', 'Valid', 'person');
    expect(id1).toStrictEqual(
      {
        authUserId: expect.any(Number),
      }
    );

    // Test for register invalid person
    const id2 = authRegisterV1('lol@gmailcom', '123', '', 'person');
    expect(id2).toStrictEqual(ERROR);

    // check person 1 is not influenced by person 2
    expect(userProfileV1(id1.authUserId, id1.authUserId)).toStrictEqual({
      user: {
        uId: id1.authUserId,
        email: 'lol@gmail.com',
        nameFirst: 'Valid',
        nameLast: 'person',
        handleStr: 'validperson'
      }
    });

    expect(userProfileV1(id1.authUserId, id2.authUserId)).toStrictEqual(ERROR);
    expect(userProfileV1(id2.authUserId, id1.authUserId)).toStrictEqual(ERROR);
  });

  test('the first user is the global user and can join any private channels', () => {
    const id1 = authRegisterV1('lol@gmail.com', '123321', 'Valid', 'person');
    const id2 = authRegisterV1('123@email.com', 'abc123', 'Someone', 'else');
    const cId = channelsCreateV1(id2.authUserId, 'demonstration', false);
    channelJoinV1(id1.authUserId, cId.channelId);
    expect(channelDetailsV1(id1.authUserId, cId.channelId)).toStrictEqual({
      name: 'demonstration',
      isPublic: false,
      ownerMembers: [{
        uId: id2.authUserId,
        email: '123@email.com',
        nameFirst: 'Someone',
        nameLast: 'else',
        handleStr: 'someoneelse'
      }],
      allMembers: [{
        uId: id2.authUserId,
        email: '123@email.com',
        nameFirst: 'Someone',
        nameLast: 'else',
        handleStr: 'someoneelse'
      },
      {
        uId: id1.authUserId,
        email: 'lol@gmail.com',
        nameFirst: 'Valid',
        nameLast: 'person',
        handleStr: 'validperson'
      }]
    });
  });

  test('Test for multiple user with the same handle str', () => {
    const id1 = authRegisterV1('123@email.com', 'abc1234', 'hello', 'world');
    const id2 = authRegisterV1('best@email.com', 'poiuyy', 'hello', 'world');
    const id3 = authRegisterV1('mid@email.com', 'hahahaha', 'hello', 'world');
    expect(userProfileV1(id1.authUserId, id1.authUserId)).toStrictEqual({
      user: {
        uId: id1.authUserId,
        email: '123@email.com',
        nameFirst: 'hello',
        nameLast: 'world',
        handleStr: 'helloworld',
      }
    });
    expect(userProfileV1(id2.authUserId, id2.authUserId)).toStrictEqual({
      user: {
        uId: id2.authUserId,
        email: 'best@email.com',
        nameFirst: 'hello',
        nameLast: 'world',
        handleStr: 'helloworld0',
      }
    });
    expect(userProfileV1(id3.authUserId, id3.authUserId)).toStrictEqual({
      user: {
        uId: id3.authUserId,
        email: 'mid@email.com',
        nameFirst: 'hello',
        nameLast: 'world',
        handleStr: 'helloworld1',
      }
    });
  });
});

describe('test for authLoginV1 function', () => {
  // Test for email doesnt belong to user
  test('unregistered email login', () => {
    const id = authLoginV1('notregistered@email.com', '135790');
    expect(id).toStrictEqual(ERROR);
    expect(userProfileV1(id.authUserId, id.authUserId)).toStrictEqual(ERROR);
  });

  test('unregistered email login if someone previously registered', () => {
    const id = authRegisterV1('123@email.com', 'abc123', 'Someone', 'interesting');
    expect(authLoginV1('good@email.com', 'abc123')).toStrictEqual(ERROR);
    expect(userProfileV1(id.authUserId, id.authUserId)).toStrictEqual({
      user: {
        uId: id.authUserId,
        email: '123@email.com',
        nameFirst: 'Someone',
        nameLast: 'interesting',
        handleStr: 'someoneinteresting'
      }
    });
  });

  test('incorrect password', () => {
    const id1 = authRegisterV1('123@email.com', 'abc123', 'sleepy', 'person');
    expect(authLoginV1('123@email.com', 'abc1234')).toStrictEqual(ERROR);
    expect(userProfileV1(id1.authUserId, id1.authUserId)).toStrictEqual({
      user: {
        uId: id1.authUserId,
        email: '123@email.com',
        nameFirst: 'sleepy',
        nameLast: 'person',
        handleStr: 'sleepyperson',
      }
    });
  });

  // Test for incorrect password inputted to correct email
  test('incorrect password for the second registered person', () => {
    const id1 = authRegisterV1('123@email.com', 'abc123', 'good', 'night');
    const id2 = authRegisterV1('medium@email.com', 'asdfgh', 'tired', 'morning');

    // Here person 2 logged in successfully but person 1 did not
    expect(authLoginV1('medium@email.com', 'asdfgh')).toStrictEqual(id2);
    expect(authLoginV1('123@email.com', 'abc1234')).toStrictEqual(ERROR);
    expect(userProfileV1(id1.authUserId, id1.authUserId)).toStrictEqual({
      user: {
        uId: id1.authUserId,
        email: '123@email.com',
        nameFirst: 'good',
        nameLast: 'night',
        handleStr: 'goodnight',
      }
    });
    expect(userProfileV1(id2.authUserId, id2.authUserId)).toStrictEqual({
      user: {
        uId: id2.authUserId,
        email: 'medium@email.com',
        nameFirst: 'tired',
        nameLast: 'morning',
        handleStr: 'tiredmorning',
      }
    });
    expect(userProfileV1(id2.authUserId, id1.authUserId)).toStrictEqual({
      user: {
        uId: id1.authUserId,
        email: '123@email.com',
        nameFirst: 'good',
        nameLast: 'night',
        handleStr: 'goodnight',
      }
    });
  });

  // Test for correct email and password
  test('Test for correct email and password', () => {
    const id = authRegisterV1('123@email.com', 'abc1234', 'hello', 'world');
    expect(authLoginV1('123@email.com', 'abc1234')).toStrictEqual(id);
    expect(userProfileV1(id.authUserId, id.authUserId)).toStrictEqual({
      user: {
        uId: id.authUserId,
        email: '123@email.com',
        nameFirst: 'hello',
        nameLast: 'world',
        handleStr: 'helloworld',
      }
    });
  });

  test('Test for correct email and password with multiple members registered', () => {
    const id1 = authRegisterV1('hello@email.com', 'password1', 'Single', 'Person1');
    const id2 = authRegisterV1('bye@email.com', 'newPassword', 'second', 'person2');
    const id3 = authRegisterV1('123@email.com', 'abc1234', 'Someone', 'else');
    const id4 = authRegisterV1('morning@email.com', 'hellooo', 'third', 'person3');

    expect(authLoginV1('123@email.com', 'abc1234')).toStrictEqual(id3);
    expect(authLoginV1('hello@email.com', 'password1')).toStrictEqual(id1);
    expect(authLoginV1('bye@email.com', 'newPassword')).toStrictEqual(id2);
    expect(userProfileV1(id2.authUserId, id1.authUserId)).toStrictEqual({
      user: {
        uId: id1.authUserId,
        email: 'hello@email.com',
        nameFirst: 'Single',
        nameLast: 'Person1',
        handleStr: 'singleperson1',
      }
    });
    expect(userProfileV1(id1.authUserId, id4.authUserId)).toStrictEqual({
      user: {
        uId: id4.authUserId,
        email: 'morning@email.com',
        nameFirst: 'third',
        nameLast: 'person3',
        handleStr: 'thirdperson3',
      }
    });
    expect(userProfileV1(id3.authUserId, id2.authUserId)).toStrictEqual({
      user: {
        uId: id2.authUserId,
        email: 'bye@email.com',
        nameFirst: 'second',
        nameLast: 'person2',
        handleStr: 'secondperson2',
      }
    });
    expect(userProfileV1(id4.authUserId, id3.authUserId)).toStrictEqual({
      user: {
        uId: id3.authUserId,
        email: '123@email.com',
        nameFirst: 'Someone',
        nameLast: 'else',
        handleStr: 'someoneelse',
      }
    });
  });
});
