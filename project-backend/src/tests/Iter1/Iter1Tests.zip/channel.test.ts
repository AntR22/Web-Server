import { clearV1 } from '../../other';

import { channelsCreateV1 } from '../../channels';

import { authRegisterV1 } from '../../auth';

import { channelMessagesV1, channelInviteV1, channelJoinV1, channelDetailsV1 } from '../../channel';

const ERROR = { error: expect.any(String) };

const start = 0;

beforeEach(() => {
  clearV1();
});

describe('test channelMessagesV1 function', () => {
  test('correct return type', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', true);
    expect(channelMessagesV1(id.authUserId, cid.channelId, start)).toStrictEqual({
      messages: [],
      start: 0,
      end: -1,
    });
  });
  test('error when: channel ID invalid', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const invalidID = -5;
    expect(channelMessagesV1(id.authUserId, invalidID, start)).toStrictEqual(ERROR);
  });
  test('error when: authUser is not a channel member', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const id2 = authRegisterV1('mum@gmail.com', 'verybadpass', 'Jina', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', true);
    expect(channelMessagesV1(id2.authUserId, cid.channelId, start)).toStrictEqual(ERROR);
  });
  test('error when: authUser ID is Invalid', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', true);
    const invalidId = -8599;
    expect(channelMessagesV1(invalidId, cid.channelId, start)).toStrictEqual(ERROR);
  });
  test('error when: start is not valid', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', true);
    const badStart = 5;
    expect(channelMessagesV1(id.authUserId, cid.channelId, badStart)).toStrictEqual(ERROR);
  });
});

describe('test channelInviteV1 function', () => {
  test('correct return type', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const id2 = authRegisterV1('mum@gmail.com', 'verybadpass', 'Jina', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', true);
    expect(channelInviteV1(id.authUserId, cid.channelId, id2.authUserId)).toStrictEqual({});
  });
  test('error when: channel ID invalid', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const id2 = authRegisterV1('mum@gmail.com', 'verybadpass', 'Jina', 'Ragusa');
    const invalidID = -5908;
    expect(channelInviteV1(id.authUserId, invalidID, id2.authUserId)).toStrictEqual(ERROR);
  });
  test('error when: uId doesnt refer to a valid user', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', true);
    const invalidID = -6996;
    expect(channelInviteV1(id.authUserId, cid.channelId, invalidID)).toStrictEqual(ERROR);
  });
  test('error when: authID is invalid', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const id2 = authRegisterV1('mum@gmail.com', 'verybadpass', 'Jina', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', true);
    const invalidID = -6996;
    expect(channelInviteV1(invalidID, cid.channelId, id2.authUserId)).toStrictEqual(ERROR);
  });
  test('error when: authId is not a member of channel', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const id2 = authRegisterV1('mum@gmail.com', 'verybadpass', 'Jina', 'Ragusa');
    const id3 = authRegisterV1('jamaica@gmail.com', 'nicenice', 'gary', 'stevens');
    const cid = channelsCreateV1(id.authUserId, 'test', true);
    expect(channelInviteV1(id2.authUserId, cid.channelId, id3.authUserId)).toStrictEqual(ERROR);
  });
  test('error when: uId is already part of the channel', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const id2 = authRegisterV1('mum@gmail.com', 'verybadpass', 'Jina', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', true);
    channelJoinV1(id2.authUserId, cid.channelId);
    expect(channelInviteV1(id.authUserId, cid.channelId, id2.authUserId)).toStrictEqual(ERROR);
  });
  test('invite correctly allows a user to join a private channel', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const id2 = authRegisterV1('mum@gmail.com', 'verybadpass', 'Jina', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', false);
    expect(channelInviteV1(id.authUserId, cid.channelId, id2.authUserId)).toStrictEqual({});
  });
});

describe('test channelDetailsV1 function', () => {
  test('error when: channel id invalid', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const invalidID = -8485;
    expect(channelDetailsV1(id.authUserId, invalidID)).toStrictEqual(ERROR);
  });
  test('error when: authUser is not apart of public channel ', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const id2 = authRegisterV1('mum@gmail.com', 'verybadpass', 'Jina', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', true);
    expect(channelDetailsV1(id2.authUserId, cid.channelId)).toStrictEqual(ERROR);
  });
  test('error when: authUser is not apart of private channel ', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const id2 = authRegisterV1('mum@gmail.com', 'verybadpass', 'Jina', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', false);
    expect(channelDetailsV1(id2.authUserId, cid.channelId)).toStrictEqual(ERROR);
  });
  test('error when: authUser id invalid', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', false);
    const invalidID = -8485;
    expect(channelDetailsV1(invalidID, cid.authUserId)).toStrictEqual(ERROR);
  });
  test('correct return type', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const id2 = authRegisterV1('mum@gmail.com', 'verybadpass', 'Jina', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', true);
    expect(channelDetailsV1(id.authUserId, cid.channelId)).toStrictEqual({
      name: 'test',
      isPublic: true,
      ownerMembers: [{
        uId: id.authUserId,
        email: 'bob@gmail.com',
        nameFirst: 'Anton',
        nameLast: 'Ragusa',
        handleStr: 'antonragusa'
      }],
      allMembers: [{
        uId: id.authUserId,
        email: 'bob@gmail.com',
        nameFirst: 'Anton',
        nameLast: 'Ragusa',
        handleStr: 'antonragusa'
      }],
    });
    const cid2 = channelsCreateV1(id2.authUserId, 'test2', false);
    expect(channelDetailsV1(id2.authUserId, cid2.channelId)).toStrictEqual({
      name: 'test2',
      isPublic: false,
      ownerMembers: [{
        uId: id2.authUserId,
        email: 'mum@gmail.com',
        nameFirst: 'Jina',
        nameLast: 'Ragusa',
        handleStr: 'jinaragusa'
      }],
      allMembers: [
        {
          uId: id2.authUserId,
          email: 'mum@gmail.com',
          nameFirst: 'Jina',
          nameLast: 'Ragusa',
          handleStr: 'jinaragusa'
        }
      ],
    });
  });
});

describe('test channelJoinV1 function', () => {
  test('error when: channel ID invalid', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const invalidID = -4839;
    expect(channelJoinV1(id.authUserId, invalidID)).toStrictEqual(ERROR);
  });
  test('error when: user already apart of channel', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const id2 = authRegisterV1('mum@gmail.com', 'verybadpass', 'Jina', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', true);
    const cid2 = channelsCreateV1(id2.authUserId, 'test2', false);
    expect(channelJoinV1(id.authUserId, cid.channelId)).toStrictEqual(ERROR);
    expect(channelJoinV1(id2.authUserId, cid2.channelId)).toStrictEqual(ERROR);
  });
  test('error when: authID is invalid', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const invalidID = -9329;
    const cid = channelsCreateV1(id.authUserId, 'test', true);
    expect(channelJoinV1(invalidID, cid.channelId)).toStrictEqual(ERROR);
  });
  test('error when: uninvited user joins private channel', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const id2 = authRegisterV1('mum@gmail.com', 'verybadpass', 'Jina', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', false);
    expect(channelJoinV1(id2.authUserId, cid.channelId)).toStrictEqual(ERROR);
  });
  test('correct return type', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const id2 = authRegisterV1('mum@gmail.com', 'verybadpass', 'Jina', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', true);
    expect(channelJoinV1(id2.authUserId, cid.channelId)).toStrictEqual({});
  });
  test('member correctly joins public channel', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const id2 = authRegisterV1('mum@gmail.com', 'verybadpass', 'Jina', 'Ragusa');
    const cid = channelsCreateV1(id.authUserId, 'test', true);
    channelJoinV1(id2.authUserId, cid.channelId);
    expect(channelDetailsV1(id2.authUserId, cid.channelId)).toStrictEqual({
      name: 'test',
      isPublic: true,
      ownerMembers: [{
        uId: id.authUserId,
        email: 'bob@gmail.com',
        nameFirst: 'Anton',
        nameLast: 'Ragusa',
        handleStr: 'antonragusa'
      }],
      allMembers: [{
        uId: id.authUserId,
        email: 'bob@gmail.com',
        nameFirst: 'Anton',
        nameLast: 'Ragusa',
        handleStr: 'antonragusa'
      },
      {
        uId: id2.authUserId,
        email: 'mum@gmail.com',
        nameFirst: 'Jina',
        nameLast: 'Ragusa',
        handleStr: 'jinaragusa'
      }],
    });
  });
  test('global owner correctly joins private channel', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const id2 = authRegisterV1('mum@gmail.com', 'verybadpass', 'Jina', 'Ragusa');
    const cid = channelsCreateV1(id2.authUserId, 'test', false);
    channelJoinV1(id.authUserId, cid.channelId);
    expect(channelDetailsV1(id2.authUserId, cid.channelId)).toStrictEqual({
      name: 'test',
      isPublic: false,
      ownerMembers: [{
        uId: id2.authUserId,
        email: 'mum@gmail.com',
        nameFirst: 'Jina',
        nameLast: 'Ragusa',
        handleStr: 'jinaragusa'
      }],
      allMembers: [{
        uId: id2.authUserId,
        email: 'mum@gmail.com',
        nameFirst: 'Jina',
        nameLast: 'Ragusa',
        handleStr: 'jinaragusa'
      },
      {
        uId: id.authUserId,
        email: 'bob@gmail.com',
        nameFirst: 'Anton',
        nameLast: 'Ragusa',
        handleStr: 'antonragusa'
      }],
    });
  });
});
