
import { authRegisterV1 } from '../../auth';

import { channelsCreateV1, channelsListV1, channelsListAllV1 } from '../../channels';

import { clearV1 } from '../../other';

const ERROR = { error: expect.any(String) };

beforeEach(() => {
  clearV1();
});

describe('test channelsCreateV1 function', () => {
  // const testId = User.authUserId;
  // Test for invalid name given to the channel
  test("Invalid name '$name'", () => {
    const User = authRegisterV1('abc@email.com', '123456', 'Example', 'person');
    expect(channelsCreateV1(User.authUserId, '', true)).toStrictEqual(ERROR);
    expect(channelsCreateV1(User.authUserId, 'an extrememememly longgggg name', false)).toStrictEqual(ERROR);
  });

  // Test for invalid UserId when isPublic is true
  test('test for invalid UserId creating a public channel', () => {
    const User = authRegisterV1('abc@email.com', '123456', 'Example', 'person');
    expect(channelsCreateV1(User.authUserId + 1, 'Random', true)).toStrictEqual(ERROR);
    expect(channelsCreateV1(User.authUserId + 2, 'Random', true)).toStrictEqual(ERROR);
    expect(channelsCreateV1(User.authUserId - 1, 'Random', true)).toStrictEqual(ERROR);
    expect(channelsCreateV1(User.authUserId - 2, 'Random', true)).toStrictEqual(ERROR);
  });

  // Test for invalid UserId when isPublic is false
  test('test for invalid UserId creating a public channel', () => {
    const User = authRegisterV1('abc@email.com', '123456', 'Example', 'person');
    expect(channelsCreateV1(User.authUserId + 1, 'Sample', false)).toStrictEqual(ERROR);
    expect(channelsCreateV1(User.authUserId + 2, 'Sample', false)).toStrictEqual(ERROR);
    expect(channelsCreateV1(User.authUserId - 2, 'Sample', false)).toStrictEqual(ERROR);
    expect(channelsCreateV1(User.authUserId - 1, 'Sample', false)).toStrictEqual(ERROR);
  });

  // Test for correct returns of a channel id
  test('one valid user creates a course', () => {
    const User = authRegisterV1('abc@email.com', '123456', 'Example', 'person');
    expect(channelsCreateV1(User.authUserId, 'Sample', false)).toStrictEqual(
      {
        channelId: expect.any(Number),
      }
    );
  });

  test('Another person creates 2 courses', () => {
    const testId2 = authRegisterV1('cool@gmail.com', 'abcdef', 'someone', 'example');
    expect(channelsCreateV1(testId2.authUserId, 'Sample', true)).toStrictEqual(
      {
        channelId: expect.any(Number),
      }
    );

    expect(channelsCreateV1(testId2.authUserId, 'Another Sample', true)).toStrictEqual(
      {
        channelId: expect.any(Number),
      }
    );
  });
});

///
describe('test channelsListV1 function', () => {
  // Test for invalid UserId
  test('Invalid UserId listing their channels', () => {
    const user = authRegisterV1('abc@email.com', '123456', 'Example', 'person');
    channelsCreateV1(user.authUserId, 'Sample', true);
    expect(channelsListV1(user.authUserId + 1)).toStrictEqual(ERROR);
  });

  // Test for valid channel lists that are created
  test('List out one channel created', () => {
    const user = authRegisterV1('abc@email.com', '123456', 'Example', 'person');
    const newChannel = channelsCreateV1(user.authUserId, 'Sample', true);
    expect(channelsListV1(user.authUserId)).toStrictEqual({
      channels: [
        {
          channelId: newChannel.channelId,
          name: 'Sample',
        }
      ]
    });
  });

  // Test out multiple channels created by one person
  test('Test out multiple channels created by multiple person', () => {
    const user = authRegisterV1('abc@email.com', '123456', 'Example', 'person');
    const newChannel = channelsCreateV1(user.authUserId, 'Sample', true);
    const user1 = authRegisterV1('no2@gmail.com', 'AbCdEf', 'Person', 'numbertwo');
    const newChannel2 = channelsCreateV1(user1.authUserId, 'Sample no2', true);
    const newChannel3 = channelsCreateV1(user.authUserId, 'Sample no3', true);

    expect(channelsListV1(user.authUserId)).toStrictEqual({
      channels: [
        {
          channelId: newChannel.channelId,
          name: 'Sample',
        },
        {
          channelId: newChannel3.channelId,
          name: 'Sample no3',
        },
      ]
    });

    expect(channelsListV1(user1.authUserId)).toStrictEqual({
      channels: [
        {
          channelId: newChannel2.channelId,
          name: 'Sample no2',
        },
      ]
    });
  });

  test('no course created and listed', () => {
    const user1 = authRegisterV1('no2@gmail.com', 'AbCdEf', 'Person', 'numbertwo');
    expect(channelsListV1(user1.authUserId)).toStrictEqual({
      channels: []
    });
  });

  // Test out different people creating multiple channels
  test('multiple channels created by one person', () => {
    const user1 = authRegisterV1('no2@gmail.com', 'AbCdEf', 'Person', 'numbertwo');
    const user2 = authRegisterV1('no3@gmail.com', 'helloworld', 'Person', 'numberthree');

    const newChannel2 = channelsCreateV1(user1.authUserId, 'user1 created no1', true);
    const newChannel3 = channelsCreateV1(user1.authUserId, 'user1 created no2', true);

    // matching the result for the first user
    expect(channelsListV1(user1.authUserId)).toStrictEqual({
      channels: [
        {
          channelId: newChannel2.channelId,
          name: 'user1 created no1',
        },
        {
          channelId: newChannel3.channelId,
          name: 'user1 created no2',
        },
      ]
    });

    // matching the result for the user1
    expect(channelsListV1(user1.authUserId)).toStrictEqual({
      channels: [{
        channelId: newChannel2.channelId,
        name: 'user1 created no1',
      },
      {
        channelId: newChannel3.channelId,
        name: 'user1 created no2',
      }
      ]
    });

    // matching channel list result for user2
    expect(channelsListV1(user2.authUserId)).toStrictEqual({
      channels: []
    });
  });
});

describe('test channelsListAllV1 function', () => {
  test('Invalid UserId listing all channels', () => {
    const user1 = authRegisterV1('abc@email.com', '123456', 'Example', 'person');
    expect(channelsListAllV1(user1.authUserId + 1)).toStrictEqual(ERROR);
    expect(channelsListAllV1(user1.authUserId + 2)).toStrictEqual(ERROR);
    expect(channelsListAllV1(user1.authUserId - 1)).toStrictEqual(ERROR);
    expect(channelsListAllV1(user1.authUserId - 2)).toStrictEqual(ERROR);
  });

  // test for empty channel list
  test('no channel listed', () => {
    const user1 = authRegisterV1('abc@email.com', '123456', 'Example', 'person');
    expect(channelsListAllV1(user1.authUserId)).toStrictEqual({
      channels: []
    });
  });

  test('one channel listed', () => {
    const user1 = authRegisterV1('abc@email.com', '123456', 'Example', 'person');
    const newChannel = channelsCreateV1(user1.authUserId, 'Sample no1', true);
    expect(channelsListAllV1(user1.authUserId)).toStrictEqual({
      channels: [{
        channelId: newChannel.channelId,
        name: 'Sample no1',
      }]
    });
  });

  test('someone from outside the channel viewing all channnels', () => {
    const user1 = authRegisterV1('abc@email.com', '123456', 'Example', 'person');
    const newChannel = channelsCreateV1(user1.authUserId, 'Sample no1', true);
    const user2 = authRegisterV1('no2@email.com', 'qwerty', 'Person', 'Numbertwo');
    expect(channelsListAllV1(user2.authUserId)).toStrictEqual({
      channels: [{
        channelId: newChannel.channelId,
        name: 'Sample no1',
      }]
    });
  });

  test('multiple people viewing multiple channels', () => {
    const user1 = authRegisterV1('abc@email.com', '123456', 'Example', 'person');
    const newChannel = channelsCreateV1(user1.authUserId, 'Sample user1 no1', true);
    const newChannel2 = channelsCreateV1(user1.authUserId, 'Sample user1 no2', true);
    const user2 = authRegisterV1('no2@email.com', 'qwerty', 'Person', 'Numbertwo');
    const user3 = authRegisterV1('no3@email.com', 'asdfgh', 'Person', 'Numberthree');
    const newChannel3 = channelsCreateV1(user3.authUserId, 'Sample user3 no1', true);

    // Expect every member should view the same list of channels
    expect(channelsListAllV1(user1.authUserId)).toStrictEqual({
      channels: [{
        channelId: newChannel.channelId,
        name: 'Sample user1 no1',
      },
      {
        channelId: newChannel2.channelId,
        name: 'Sample user1 no2',
      },
      {
        channelId: newChannel3.channelId,
        name: 'Sample user3 no1',
      }
      ]
    });

    expect(channelsListAllV1(user2.authUserId)).toStrictEqual({
      channels: [{
        channelId: newChannel.channelId,
        name: 'Sample user1 no1',
      },
      {
        channelId: newChannel2.channelId,
        name: 'Sample user1 no2',
      },
      {
        channelId: newChannel3.channelId,
        name: 'Sample user3 no1',
      }
      ]
    });

    expect(channelsListAllV1(user3.authUserId)).toStrictEqual({
      channels: [{
        channelId: newChannel.channelId,
        name: 'Sample user1 no1',
      },
      {
        channelId: newChannel2.channelId,
        name: 'Sample user1 no2',
      },
      {
        channelId: newChannel3.channelId,
        name: 'Sample user3 no1',
      }
      ]
    });
  });
});
