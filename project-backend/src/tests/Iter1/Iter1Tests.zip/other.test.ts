import { clearV1 } from '../../other';

import { channelsCreateV1, channelsListAllV1 } from '../../channels';

import { authRegisterV1 } from '../../auth';

import { userProfileV1 } from '../../users';

const ERROR = { error: expect.any(String) };

describe('test clearV1 function', () => {
  test('returns empty data', () => {
    expect(clearV1()).toStrictEqual({});
  });
  test('empties datastore', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    channelsCreateV1(id.authUserId, 'test', true);
    clearV1();
    expect(channelsListAllV1(id.authUserId)).toStrictEqual(ERROR);
    expect(userProfileV1(id.authUserId, id.authUserId)).toStrictEqual(ERROR);
  });
});
