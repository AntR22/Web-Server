
import { clearV1 } from '../../other';

import { authRegisterV1 } from '../../auth';

import { userProfileV1 } from '../../users';

const ERROR = { error: expect.any(String) };

beforeEach(() => {
  clearV1();
});

describe('test userProfileV1 function', () => {
  test('returns error when authID is invalid', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    expect(userProfileV1(id.authUserId, -6574)).toStrictEqual(ERROR);
  });
  test('returns error when uID does not refer to valid user', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    expect(userProfileV1(-4984, id.authUserId)).toStrictEqual(ERROR);
  });
  test('correct functionality case 1', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    expect(userProfileV1(id.authUserId, id.authUserId)).toStrictEqual({
      user: {
        uId: expect.any(Number),
        email: 'bob@gmail.com',
        nameFirst: 'Anton',
        nameLast: 'Ragusa',
        handleStr: 'antonragusa'
      }
    });
  });
  test('correct functionality case 2', () => {
    const id = authRegisterV1('bob@gmail.com', 'Gpassword', 'Anton', 'Ragusa');
    const id2 = authRegisterV1('mum@gmail.com', 'verybadpass', 'Jina', 'Ragusa');
    expect(userProfileV1(id2.authUserId, id.authUserId)).toStrictEqual({
      user: {
        uId: expect.any(Number),
        email: 'bob@gmail.com',
        nameFirst: 'Anton',
        nameLast: 'Ragusa',
        handleStr: 'antonragusa'
      }
    });
  });
});
